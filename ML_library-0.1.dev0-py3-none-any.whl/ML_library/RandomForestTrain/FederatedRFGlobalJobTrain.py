import pickle
from ML_library.Job import Job


class FederatedRFGlobalJobTrain(Job):
    local_outputs_paths = ""
    output_path = ""

    def __init__(self, local_outputs_paths, output_path):
        super().__init__(output_path)
        self.local_outputs_paths = local_outputs_paths.split(',')

    def execute(self):
        self.global_job_init()

    def global_job_init(self):
        global_forest = None
        for i, local_forest_path in enumerate(self.local_outputs_paths):
            with open(local_forest_path, 'rb') as pkl_input:
                local_forest = pickle.load(pkl_input)
                if i == 0:
                    global_forest = local_forest
                    continue
                else:
                    global_forest.estimators_ += local_forest.estimators_
        global_forest.n_estimators = len(global_forest.estimators_)

        # print(global_forest)

        with open('{}.pkl'.format(self.output_path + "/global_forest"), 'wb') as output:
            pickle.dump(global_forest, output, pickle.HIGHEST_PROTOCOL)

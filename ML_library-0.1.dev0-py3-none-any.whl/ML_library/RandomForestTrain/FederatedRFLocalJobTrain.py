import csv
import pickle
from random import shuffle
from sklearn.ensemble import RandomForestClassifier
from ML_library.Job import Job


class FederatedRFLocalJobTrain(Job):
    data_set_path = ""
    output_path = ""
    n_estimators = 10
    max_depth = None
    min_samples_leaf = 1
    forest = None
    criterion = 'gini'
    min_samples_split = 2
    max_features = 'auto'
    is_shuffle = False
    bootstrap = True
    oob_score = False
    n_jobs = None
    random_state = None
    class_weight = None

    def __init__(self, data_set_path, output_path, is_shuffle=False, max_features='auto', max_depth=None,
                 min_samples_split=2, min_samples_leaf=1, n_estimators=10,
                 criterion='gini', random_state=None, n_jobs=None, oob_score=False,
                 bootstrap=True, class_weight=None):
        super().__init__(output_path)
        self.data_set_path = data_set_path
        self.n_estimators = n_estimators
        self.train_features = []
        self.train_labels = []
        self.test_features = []
        self.test_labels = []
        self.is_shuffle = is_shuffle
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.min_samples_split = min_samples_split
        self.criterion = criterion
        self.max_features = max_features
        self.bootstrap = bootstrap
        self.oob_score = oob_score
        self.n_jobs = n_jobs
        self.random_state = random_state
        self.class_weight = class_weight

    def execute(self):
        self.local_job_init()

    def local_job_init(self):
        self.init_train_data()
        self.train()
        self.save_random_forest()

    def init_train_data(self):
        train_features = []
        train_labels = []
        with open(self.data_set_path, newline='') as csv_file:
            reader = csv.reader(csv_file)
            for row in reader:
                features = row[:-1]
                train_features.append(features)
                train_labels.append(row[-1])
        if self.is_shuffle:
            train_data = []
            for i in range(len(train_features)):
                train_data.append([train_features[i], train_labels[i]])  # TODO use numpy . concatenate

            shuffle(train_data)

            self.train_features = [item[0] for item in train_data]
            self.train_labels = [item[1] for item in train_data]
        else:
            self.train_labels = train_labels
            self.train_features = train_features

    def train(self):
        self.forest = RandomForestClassifier(n_estimators=self.n_estimators, min_samples_leaf=self.min_samples_leaf,
                                             max_depth=self.max_depth, min_samples_split=self.min_samples_split,
                                             criterion=self.criterion, max_features=self.max_features,
                                             bootstrap=self.bootstrap, oob_score=self.oob_score,
                                             n_jobs=self.n_jobs, random_state=self.random_state,
                                             class_weight=self.class_weight)
        self.forest.fit(self.train_features, self.train_labels)

    def save_random_forest(self):
        with open('{}.pkl'.format(self.output_path + "/forest"), 'wb') as output:
            pickle.dump(self.forest, output, pickle.HIGHEST_PROTOCOL)

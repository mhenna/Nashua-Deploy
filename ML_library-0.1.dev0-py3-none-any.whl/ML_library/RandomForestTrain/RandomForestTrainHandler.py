import os
import argparse
from ML_library.RandomForestTrain.FederatedRFGlobalJobTrain import FederatedRFGlobalJobTrain
from ML_library.RandomForestTrain.FederatedRFLocalJobTrain import FederatedRFLocalJobTrain
from ML_library.Job import Job


class RandomForestTrainHandler(Job):
    class_object = None
    parser = None

    def __init__(self, args):
        self.create_parser()
        args, extra_args = self.parser.parse_known_args(args)

        input_path = args.inputPath
        prev_paths = args.previousResults
        output_path = args.outputPath
        is_shuffle = args.isShuffle
        n_estimators = args.nEstimators
        oob_score = args.oobScore
        try:
            max_features = eval(args.maxFeatures)
        except TypeError and NameError:
            max_features = args.maxFeatures
        min_samples_leaf = args.minSamplesLeaf
        min_samples_split = args.minSamplesSplit
        criterion = args.criterion
        class_weight = args.classWeight
        bootstrap = args.bootstrap
        n_jobs = args.nJobs
        random_state = args.randomState
        max_depth = args.maxDepth
        is_global = args.isGlobal

        super(RandomForestTrainHandler, self).__init__(output_path)

        # local_prev_paths = ""
        # global_prev_paths = ""

        if not os.path.exists(output_path):
            os.makedirs(output_path)

        # prev_paths_array = prev_paths.split(",")
        # for i, prev_path in enumerate(prev_paths_array):
        #     if "/local" in prev_path:
        #         if local_prev_paths != "":
        #             local_prev_paths += ','
        #         local_prev_paths += prev_path
        #     else:
        #         if global_prev_paths != "":
        #             global_prev_paths += ','
        #         global_prev_paths += prev_path

        print("IN MAIN input_path: ", input_path)
        if is_global != 'true':
            print("IN MAIN prev_paths: ", prev_paths)
        print("IN MAIN output_path: ", output_path)
        print("IN MAIN is_global: ", is_global)

        if is_global == 'true':  # Global job
            self.class_object = FederatedRFGlobalJobTrain(prev_paths, output_path)
        else:
            self.class_object = FederatedRFLocalJobTrain(input_path, output_path, is_shuffle=is_shuffle,
                                                         n_estimators=n_estimators,
                                                         min_samples_leaf=min_samples_leaf, max_depth=max_depth,
                                                         min_samples_split=min_samples_split, criterion=criterion,
                                                         max_features=max_features, bootstrap=bootstrap,
                                                         oob_score=oob_score, n_jobs=n_jobs, random_state=random_state,
                                                         class_weight=class_weight)

    def execute(self):
        self.class_object.execute()

    def create_parser(self):
        self.parser = argparse.ArgumentParser()
        self.parser.add_argument("--inputPath")
        self.parser.add_argument("--testPath")
        self.parser.add_argument("--previousResults")
        self.parser.add_argument("--outputPath")
        self.parser.add_argument("--isShuffle", default=False, const=True, nargs='?', type=bool)
        self.parser.add_argument("--nEstimators", default=10, type=int)
        self.parser.add_argument("--oobScore", default=False, const=True, nargs='?', type=bool)
        self.parser.add_argument("--maxFeatures", default='auto')
        self.parser.add_argument("--minSamplesLeaf", default=1, type=int)
        self.parser.add_argument("--minSamplesSplit", default=2, type=int)
        self.parser.add_argument("--criterion", default='gini')
        self.parser.add_argument("--classWeight", default=None)
        self.parser.add_argument("--bootstrap", default=False, const=True,nargs='?',  type=bool)
        self.parser.add_argument("--nJobs", default=None, type=int)
        self.parser.add_argument("--randomState", default=None, type=int)
        self.parser.add_argument("--maxDepth", default=None, type=int)
        self.parser.add_argument("--isGlobal")

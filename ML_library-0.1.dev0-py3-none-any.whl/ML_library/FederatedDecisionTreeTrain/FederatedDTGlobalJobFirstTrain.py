import pickle
import shutil
from ML_library.FederatedDecisionTreeTrain.DecisionTreeExecutor import DecisionTreeExecutor
from ML_library.Job import Job


class FederatedDTGlobalJobFirstTrain(Job):
    local_outputs_paths = []
    output_path = ""

    def __init__(self, local_outputs_paths, output_path, max_depth):
        super().__init__(output_path)
        self.local_outputs_paths = local_outputs_paths.split(',')
        self.output_path = output_path
        self.max_depth = max_depth

    def execute(self):
        self.global_job_init()

    def global_job_init(self):
        print("IN GLOBAL 1 local_outputs_paths: ", self.local_outputs_paths)
        print("IN GLOBAL 1 output_path: ", self.output_path)
        local_attributes_min_max_list = []
        for file_path in self.local_outputs_paths:
            local_attributes_min_max_list.append(self.read_object_from_file(file_path))
        global_attributes_min_max = DecisionTreeExecutor.execute_global(1, local_attributes_min_max_list, [], [], [],
                                                                        self.max_depth, None)
        self.add_object_to_file(global_attributes_min_max)
        print("REMOVING FILES")
        for file_path in self.local_outputs_paths:
            shutil.rmtree('/'.join(file_path.split('/')[:-1]))  # deletes the previous local directories after using it

    def add_object_to_file(self, global_attributes_min_max):
        print("global 1 Creating Output file: ", '{}/first_global_output.pkl'.format(self.output_path))
        print("global 1 Inserting in Output file: ", global_attributes_min_max)
        with open('{}/first_global_output.pkl'.format(self.output_path), 'wb') as output:
            pickle.dump(global_attributes_min_max, output, pickle.HIGHEST_PROTOCOL)

    @staticmethod
    def read_object_from_file(path):
        with open(path, 'rb') as pkl_input:
            data = pickle.load(pkl_input)
            return data

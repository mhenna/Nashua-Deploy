import pickle
import os
import shutil
from ML_library.FederatedDecisionTreeTrain.DecisionTreeExecutor import DecisionTreeExecutor
from ML_library.Job import Job


class FederatedDTGlobalJobSecondTrain(Job):
    local_outputs_paths = []
    output_path = ""
    max_depth = 0

    def __init__(self, local_outputs_paths, previous_global_path, output_path, attributes, bins_array, max_depth):
        super().__init__(output_path)
        self.local_outputs_paths = local_outputs_paths.split(',')
        self.output_path = output_path
        self.attributes = attributes
        self.previous_global_path = previous_global_path
        self.bins_array = bins_array
        self.max_depth = max_depth

    def execute(self):
        self.global_job_init()

    def global_job_init(self):
        print("IN Global 2: ", )
        print("IN Global 2 local_outputs_paths: ", self.local_outputs_paths)
        print("IN Global 2 output_path: ", self.output_path)
        print("IN Global 2 attributes: ", self.attributes)
        print("IN Global 2 previous_global_path: ", self.previous_global_path)
        print("IN Global 2 bins_array: ", self.bins_array)
        print("IN Global 2 max_depth: ", self.max_depth)
        tree = self.read_object_from_file("{}.pkl".format(self.previous_global_path + "/tree"))
        local_outputs = self.preprocess_data()
        querying_parameters = self.read_querying_parameters()
        tree, resulting_branches = DecisionTreeExecutor.execute_global(
            2, local_outputs, self.attributes, self.bins_array, eval(querying_parameters), self.max_depth, tree)
        self.remove_the_resulting_branch_from_file()
        self.add_tree_to_file(tree)
        self.add_resulting_branches_to_output__file(tree, resulting_branches)
        try:
            shutil.rmtree(self.previous_global_path)  # deletes the previous global directory after using it
        except FileNotFoundError:
            pass
        for file_path in self.local_outputs_paths:
            shutil.rmtree('/'.join(file_path.split('/')[:-1]))  # deletes the previous local directories after using it

    def preprocess_data(self):
        local_values = []
        local_values_count = []
        local_values_class_counts = []
        for file_path in self.local_outputs_paths:
            output_list = self.read_object_from_file(file_path)
            local_values.append(output_list[0])
            local_values_count.append(output_list[1])
            local_values_class_counts.append(output_list[2])

        return [local_values, local_values_count, local_values_class_counts]

    def read_querying_parameters(self):
        try:
            with open(self.previous_global_path + "/querying_values.txt", "r") as txt_file:
                return txt_file.readline()
        except FileNotFoundError:
            print("____FILE NOT FOUND ERROR____ read_querying_parameters __________: ",
                  self.previous_global_path + "/querying_values.txt")
            return '[]'

    def add_tree_to_file(self, tree):
        with open('{}.pkl'.format(self.output_path + "/tree"), 'wb') as output:
            pickle.dump(tree, output, pickle.HIGHEST_PROTOCOL)

    def remove_the_resulting_branch_from_file(self):
        try:
            with open(self.previous_global_path + "/querying_values.txt", 'r') as file_read:
                data = file_read.read().splitlines(True)
            with open(self.previous_global_path + "/querying_values.txt", 'w') as file_write:
                file_write.writelines(data[1:])
        except FileNotFoundError:
            print("____FILE NOT FOUND ERROR_________ remove_the_resulting_branch_from_file __________: ",
                  self.previous_global_path + "/querying_values.txt")
            return

    def add_resulting_branches_to_output__file(self, tree, resulting_branches):
        try:
            with open(self.previous_global_path + "/querying_values.txt", 'r') as original:
                data = original.read()
        except FileNotFoundError:
            print("____FILE NOT FOUND ERROR____ add_resulting_branches_to_output__file __________: ",
                  self.previous_global_path + "/querying_values.txt")
            data = ""
        with open(self.output_path + "/querying_values.txt", 'w') as modified:
            new_lines = ""
            if resulting_branches:
                for line in resulting_branches:
                    new_lines += str(line) + '\n'
            modified.write(new_lines + data)
            if not resulting_branches and data == "":
                if not os.path.exists(self.output_path + "/DONE_"):
                    os.makedirs(self.output_path + "/DONE_")
                with open('{}.pkl'.format(self.output_path + "/DONE_" + "/tree"), 'wb') as output:
                    pickle.dump(tree, output, pickle.HIGHEST_PROTOCOL)

    @staticmethod
    def read_object_from_file(path):
        try:
            with open(path, 'rb') as pkl_input:
                data = pickle.load(pkl_input)
                return data
        except FileNotFoundError:
            print("____FILE NOT FOUND ERROR____ read_object_from_file __________: ",
                  path)
            return None

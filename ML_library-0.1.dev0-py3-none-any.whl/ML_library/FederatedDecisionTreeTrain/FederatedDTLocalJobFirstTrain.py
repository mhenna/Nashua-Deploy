import csv
import pickle
from ML_library.FederatedDecisionTreeTrain.DecisionTreeExecutor import DecisionTreeExecutor
from ML_library.Job import Job


class FederatedDTLocalJobFirstTrain(Job):
    data_set_path = ""
    previous_global_output = ""
    output_path = ""
    bins_array = []

    def __init__(self, data_set_path, previous_global_output, output_path, bins_array):
        super().__init__(output_path)
        self.data_set_path = data_set_path
        self.previous_global_output = previous_global_output
        self.output_path = output_path
        self.bins_array = bins_array

    def execute(self):
        self.local_job_init()

    def local_job_init(self):
        print("IN LOCAL JOB 1 data set path: ", self.data_set_path)
        print("IN LOCAL JOB 1 previous: ", self.previous_global_output)
        print("IN LOCAL JOB 1 output path: ", self.output_path)
        data, attributes = self.read_data()
        querying_parameters = self.read_querying_parameters()
        attributes_min_max = DecisionTreeExecutor.execute_local(1, data, eval(querying_parameters), "", attributes,
                                                                self.bins_array)
        self.add_object_to_file(attributes_min_max)

    def add_object_to_file(self, attributes_min_max):
        print("local 1 Creating Output file: ", '{}/first_out.pkl'.format(self.output_path))
        print("local 1 Inserting in Output file: ", attributes_min_max)
        with open('{}/first_out.pkl'.format(self.output_path), 'wb') as output:
            pickle.dump(attributes_min_max, output, pickle.HIGHEST_PROTOCOL)

    def read_data(self):  # reads the data from the file (database)
        data = []
        with open(self.data_set_path, newline='') as csv_file:
            attributes = csv_file.readline().replace('\r\n', '')
            reader = csv.reader(csv_file)
            for row in reader:
                data.append(row)
        return data, attributes.split(',')

    def read_querying_parameters(self):
        if self.previous_global_output == 'null':
            return '[]'
        with open("{}/querying_values.txt".format(self.previous_global_output), "r") as txt_file:
            return txt_file.readline()

    @staticmethod
    def read_object_from_file(path):
        with open(path, 'rb') as pkl_input:
            data = pickle.load(pkl_input)
            return data

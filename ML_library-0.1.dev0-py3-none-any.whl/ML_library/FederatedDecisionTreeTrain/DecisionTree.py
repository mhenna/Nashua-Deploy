class DecisionTree(object):
    root = ""

    def __init__(self, data, edge_values):
        self.root = Node(data, edge_values)


class Node(object):
    data = ""
    edge_values = []
    children = []
    occurrence_count = 0
    class_value = ""
    all_count = 0

    def __init__(self, data, edge_values):
        self.data = data
        self.edge_values = edge_values
        self.children = [None for _ in range(len(edge_values))]

    def add_child_node(self, node, index):
        self.children[index] = node

    def print_tree(self, number_of_tabs):
        tabs = ''
        for _ in range(number_of_tabs):
            tabs += '\t'
        if self.data == 'Pure':
            answer = "\n {}Pure Node {}  {} values are: {} ".format(tabs, self.occurrence_count, self.edge_values[0],
                                                                    self.class_value)
        elif self.data == 'Impure':
            answer = "\n {}Impure Node {}  values are: {} ".format(tabs, self.occurrence_count, self.class_value)
        elif self.data == 'Empty':
            answer = "\n {}Empty Node".format(tabs)
        # elif self.data == 'Max_Depth':
        #     answer = "\n {}Max_Depth Node".format(tabs)
        else:
            answer = '\n'
            answer += tabs + "Data: " + self.data + "\n"
            # answer += tabs + "Count: " + str(self.all_count) + "\n"
            answer += tabs + "Edges: "
            for i, edge_value in enumerate(self.edge_values):
                answer += str(edge_value)
                if i != len(self.edge_values) - 1:
                    answer += ", "

            answer += "\n" + tabs + "Children: "
            for child in self.children:
                if child is None:
                    continue
                answer += child.print_tree(number_of_tabs + 1)
        return answer

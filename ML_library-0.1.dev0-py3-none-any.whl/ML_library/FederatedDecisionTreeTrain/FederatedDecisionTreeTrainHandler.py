import os
import argparse
from ML_library.FederatedDecisionTreeTrain.FederatedDTGlobalJobFirstTrain import FederatedDTGlobalJobFirstTrain
from ML_library.FederatedDecisionTreeTrain.FederatedDTGlobalJobSecondTrain import FederatedDTGlobalJobSecondTrain
from ML_library.FederatedDecisionTreeTrain.FederatedDTLocalJobFirstTrain import FederatedDTLocalJobFirstTrain
from ML_library.FederatedDecisionTreeTrain.FederatedDTLocalJobSecondTrain import FederatedDTLocalJobSecondTrain
from ML_library.Job import Job


class FederatedDecisionTreeTrainHandler(Job):
    class_object = None
    parser = None

    def __init__(self, args):
        self.create_parser()

        args, extra_args = self.parser.parse_known_args(args)

        input_path = args.inputPath
        prev_paths = args.previousResults
        output_path = args.outputPath
        max_depth = args.maxDepth
        bins_array = eval(args.binsArray)
        attributes = eval(args.attributes)
        is_global = args.isGlobal
        iteration_number = args.iterationId

        super().__init__(output_path)

        if not os.path.exists(output_path):
            os.makedirs(output_path)

        local_prev_paths = ""
        global_prev_paths = ""

        prev_paths_array = prev_paths.split(",")
        for i, prev_path in enumerate(prev_paths_array):
            if "/local" in prev_path:
                if local_prev_paths != "":
                    local_prev_paths += ','
                local_prev_paths += prev_path
            else:
                if global_prev_paths != "":
                    global_prev_paths += ','
                global_prev_paths += prev_path

        previous_global_two_output = '/'.join(output_path.split('/', 2)[:2]) + '/intermediate/' + \
                                     str(iteration_number - 2) + '/global/'

        print("IN MAIN previous_global_two_output: ", previous_global_two_output)
        print("IN MAIN input_pat: ", input_path)
        if is_global != 'true':
            print("IN MAIN prev_paths: ", prev_paths)
        print("IN MAIN output_path: ", output_path)
        print("IN MAIN max_depth: ", max_depth)
        print("IN MAIN bins_array: ", bins_array)
        print("IN MAIN attributes: ", attributes)
        print("IN MAIN is_global: ", is_global)
        print("IN MAIN iteration_number: ", iteration_number)

        if is_global == 'true':  # Global job
            if iteration_number % 2 != 0:  # Odd so First JOB
                self.class_object = FederatedDTGlobalJobFirstTrain(local_prev_paths, output_path, max_depth)

            else:  # EVEN so Second JOB
                self.class_object = FederatedDTGlobalJobSecondTrain(local_prev_paths, previous_global_two_output,
                                                                    output_path, attributes, bins_array, max_depth)

        else:
            if iteration_number % 2 != 0:  # Odd so First JOB
                if iteration_number == 1:
                    querying_parameters_path = "null"
                else:
                    querying_parameters_path = global_prev_paths
                self.class_object = FederatedDTLocalJobFirstTrain(input_path, querying_parameters_path,
                                                                  output_path, bins_array)
            else:  # EVEN so Second JOB
                self.class_object = FederatedDTLocalJobSecondTrain(input_path, global_prev_paths,
                                                                   previous_global_two_output, output_path,
                                                                   bins_array)

    def execute(self):
        self.class_object.execute()

    def create_parser(self):
        self.parser = argparse.ArgumentParser()
        self.parser.add_argument("--inputPath")
        self.parser.add_argument("--testPath")
        self.parser.add_argument("--previousResults")
        self.parser.add_argument("--outputPath")
        self.parser.add_argument("--binsArray")
        self.parser.add_argument("--attributes")
        self.parser.add_argument("--isGlobal")
        self.parser.add_argument("--maxDepth", type=int)
        self.parser.add_argument("--iterationId", type=int)

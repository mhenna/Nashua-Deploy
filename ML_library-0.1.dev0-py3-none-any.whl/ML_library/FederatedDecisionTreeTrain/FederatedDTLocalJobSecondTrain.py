import csv
import pickle
from ML_library.FederatedDecisionTreeTrain.DecisionTreeExecutor import DecisionTreeExecutor
from ML_library.Job import Job


class FederatedDTLocalJobSecondTrain(Job):
    data_set_path = ""
    previous_global_output = ""
    output_path = ""
    bins_array = []

    def __init__(self, data_set_path, previous_global_one_output, previous_global_two_output, output_path, bins_array):
        super().__init__(output_path)
        self.data_set_path = data_set_path
        self.previous_global_one_output = previous_global_one_output  # one file /first_global_output.pkl
        self.previous_global_two_output = previous_global_two_output  # list of two files /tree and /querying_values
        self.output_path = output_path
        self.bins_array = bins_array

    def execute(self):
        self.local_job_init()

    def local_job_init(self):
        print("IN LOCAL 2: ", )
        print("IN LOCAL 2 data_set_path: ", self.data_set_path)
        print("IN LOCAL 2 previous_global_one_output: ", self.previous_global_one_output)
        print("IN LOCAL 2 previous_global_two_output: ", self.previous_global_two_output)
        print("IN LOCAL 2 output_path: ", self.output_path)
        data, attributes = self.read_data()
        global_attributes_min_max = self.read_object_from_file()
        querying_parameters = self.read_querying_parameters()
        values, values_count, values_class_counts = DecisionTreeExecutor.execute_local(
            2, data, eval(querying_parameters), global_attributes_min_max, attributes, self.bins_array)
        return_object = [values, values_count, values_class_counts]
        self.add_object_to_file(return_object)

    def add_object_to_file(self, return_object):  # adds a line in the file (entry in the database)
        print("WRITING IN LOCAL 2 In File : ", '{}/second_out.pkl'.format(self.output_path))
        print("WRITING IN LOCAL 2: ", return_object)
        with open('{}/second_out.pkl'.format(self.output_path), 'wb') as output:
            pickle.dump(return_object, output, pickle.HIGHEST_PROTOCOL)

    def read_data(self):  # reads the data from the file (database)
        data = []
        with open(self.data_set_path, newline='') as csv_file:
            attributes = csv_file.readline().replace('\r\n', '')
            reader = csv.reader(csv_file)
            for row in reader:
                data.append(row)
        return data, attributes.split(',')

    def read_object_from_file(self):
        with open('{}/first_global_output.pkl'.format(self.previous_global_one_output), 'rb') as pkl_input:
            data = pickle.load(pkl_input)
            return data

    def read_querying_parameters(self):
        try:
            with open(self.previous_global_two_output + "/querying_values.txt", "r") as txt_file:
                return txt_file.readline()
        except FileNotFoundError:
            return '[]'

from ML_library.FederatedDecisionTreeTrain.DecisionTree import DecisionTree, Node


class DecisionTreeExecutor(object):
    @staticmethod
    def execute_local(iteration_number, data_set, querying_parameters, global_outputs, attributes, bins_array):
        continuous_attributes = [attribute for i, attribute in enumerate(attributes) if bins_array[i]]
        if iteration_number == 1:
            queried_data = DecisionTreeExecutor.query_data(data_set, querying_parameters, attributes,
                                                           continuous_attributes)
            # TODO query once in each iteration
            return DecisionTreeExecutor.get_local_min_max_for_each_attribute(queried_data, attributes,
                                                                             continuous_attributes)
        else:
            queried_data = DecisionTreeExecutor.query_data(data_set, querying_parameters, attributes,
                                                           continuous_attributes)
            values = DecisionTreeExecutor.get_local_values_for_each_attribute(queried_data, attributes, bins_array,
                                                                              continuous_attributes,
                                                                              global_outputs)
            values_counts = DecisionTreeExecutor.get_local_count_for_all_values_in_attributes(queried_data, bins_array,
                                                                                              attributes, values)
            values_class_counts = DecisionTreeExecutor.get_local_count_for_all_class_values_in_values_in_attributes(
                queried_data, bins_array, attributes, values)
            return values, values_counts, values_class_counts

    @staticmethod
    def execute_global(iteration_number, local_outputs, attributes, bins_array,
                       querying_values, max_depth, global_tree):
        if iteration_number == 1:
            return DecisionTreeExecutor.get_global_min_max_for_each_attribute(local_outputs)
        else:
            continuous_attributes = [attribute for i, attribute in enumerate(attributes) if bins_array[i]]
            global_values = DecisionTreeExecutor.get_global_values_for_each_attribute(local_outputs[0])
            global_values_counts = DecisionTreeExecutor.get_global_counts_for_all_values_in_attributes(
                attributes, continuous_attributes, local_outputs[1])
            global_values_class_counts = \
                DecisionTreeExecutor.get_global_count_for_all_class_values_in_values_in_attributes(
                    attributes, continuous_attributes, local_outputs[2])

            class_value_count = global_values_counts[-1]
            global_count = sum(list(global_values_counts[-1].values()))

            parent_global_count = 0
            if querying_values:
                parent_global_count = \
                    DecisionTreeExecutor.get_node_from_tree(global_tree, querying_values).all_count

            if (parent_global_count == global_count or global_count == 0) and querying_values:
                if parent_global_count == global_count:
                    attribute, values, value_ginis, class_values, pure_attribute_class_values, \
                        pure_attribute_class_count, impure_class_count = "Impure", "Impure", "Impure",\
                                                                         global_values[-1], "Impure", "Impure", "Impure"
                    # TODO HANDLE THESE SEVEN Impurities
                else:
                    attribute, values, value_ginis, class_values, pure_attribute_class_values, \
                        pure_attribute_class_count, impure_class_count = "Empty", "Empty", "Empty", "Empty", "Empty", \
                                                                         "Empty", "Empty"
                    # TODO HANDLE THESE SEVEN EMPTIES
            else:
                attribute, values, value_ginis, class_values, pure_attribute_class_values, \
                    pure_attribute_class_count, impure_class_count =\
                    DecisionTreeExecutor.get_the_partitioning_attribute(
                        querying_values, attributes, continuous_attributes, global_values, global_values_counts,
                        global_values_class_counts)

            return DecisionTreeExecutor.update_decision_tree(global_tree, querying_values, max_depth, attribute, values,
                                                             value_ginis, class_values, pure_attribute_class_values,
                                                             pure_attribute_class_count, impure_class_count,
                                                             continuous_attributes, attributes, class_value_count)

    @staticmethod
    def find_bins_for_attribute(attributes_list, bins_array, attribute, attributes_global_min_max):
        index_of_attribute = attributes_list.index(attribute)
        number_of_bins = bins_array[index_of_attribute][0]
        min_max_tuple = attributes_global_min_max[index_of_attribute]
        interval = (float(min_max_tuple[1]) - float(min_max_tuple[0])) / number_of_bins
        bins = []
        for i in range(number_of_bins):
            bins.append(min_max_tuple[0] + interval * i)
        return bins

    @staticmethod
    def query_data(data, querying_parameters, attributes, continuous_attributes):
        if not querying_parameters:
            return data

        for attribute, value in querying_parameters:
            if attribute in continuous_attributes:
                try:
                    if value[0] == '>':  # checks the condition of the branch
                        value = value.split('>')[1]
                        index_of_attribute = attributes.index(attribute)
                        data = [row for row in data if
                                float(row[index_of_attribute]) > float(value)]
                        # removes data not greater than to row value
                    else:
                        value = value.split('=')[1]
                        index_of_attribute = attributes.index(attribute)
                        data = [row for row in data if
                                float(row[index_of_attribute]) <= float(value)]
                        # removes data not smaller than nor equal to row value
                except ValueError:
                    return []
            else:
                try:
                    index_of_attribute = attributes.index(attribute)
                    data = [row for row in data if row[index_of_attribute] == value]
                    # removes data not equal to row value
                except ValueError:
                    return []
        return data

    @staticmethod
    def get_local_min_max_for_each_attribute(data, attributes, continuous_attributes):
        attributes_min_max = [[] for _ in attributes]
        if not data:
            return attributes_min_max
        for i, attribute in enumerate(attributes):
            if attribute in continuous_attributes:
                min_so_far = float(data[0][i])
                max_so_far = float(data[0][i])
                for row in data:
                    if float(row[i]) < min_so_far:
                        min_so_far = float(row[i])
                    elif float(row[i]) > max_so_far:
                        max_so_far = float(row[i])
                attributes_min_max[i] = [min_so_far, max_so_far]
        return attributes_min_max

    @staticmethod
    def get_global_min_max_for_each_attribute(local_attributes_min_max_list):
        attributes_min_max_so_far = local_attributes_min_max_list[0]
        for local_attributes_min_max in local_attributes_min_max_list:
            for i, attribute_min_max in enumerate(local_attributes_min_max):
                if not attribute_min_max:
                    continue
                if not attributes_min_max_so_far[i]:
                    attributes_min_max_so_far[i] = attribute_min_max
                    continue
                if attribute_min_max[0] < attributes_min_max_so_far[i][0]:
                    attributes_min_max_so_far[i][0] = attribute_min_max[0]
                if attribute_min_max[1] > attributes_min_max_so_far[i][1]:
                    attributes_min_max_so_far[i][1] = attribute_min_max[1]
        return attributes_min_max_so_far

    @staticmethod
    def get_local_values_for_each_attribute(data, attributes_list, bins_array, continuous_attributes,
                                            attributes_global_min_max):
        # get the distinct values for each attribute in the file in case of categorized attribute
        # get the distinct bin values for each attribute in the file in case of continuous attribute
        values = [list([]) for _ in attributes_list]

        if not data:
            return values

        for i, attribute in enumerate(attributes_list):
            if attributes_list[i] in continuous_attributes:
                values[i] = DecisionTreeExecutor.find_bins_for_attribute(attributes_list, bins_array,
                                                                         attributes_list[i], attributes_global_min_max)
        for row in data:
            for i, element in enumerate(row):
                if attributes_list[i] in continuous_attributes:
                    continue
                else:
                    if element not in values[i]:
                        values[i].append(element)
        return values

    @staticmethod
    def get_global_values_for_each_attribute(datazones_local_values):
        # returns all distinct values for each attribute from all files (datazones) in case of categorized attribute
        # returns all distinct bin values for each attribute from all files (datazones) in case of continuous attribute
        global_values = datazones_local_values[0]
        for local_values in datazones_local_values[1:]:
            for i, local_attribute_values in enumerate(local_values):
                for value in local_attribute_values:
                    if value not in global_values[i]:
                        global_values[i].append(value)
        return global_values

    @staticmethod
    def get_local_count_for_all_values_in_attributes(data, bins_array, attributes_list, local_values):
        values_counts = [{} for _ in attributes_list]
        for i, attribute in enumerate(attributes_list):
            value_count_dict = {}
            for value in local_values[i]:
                value_count_dict[value] = DecisionTreeExecutor.get_local_count_for_attribute_with_value(
                    data, bins_array, attributes_list, attribute, value)
            values_counts[i] = value_count_dict
        return values_counts

    @staticmethod
    def get_global_counts_for_all_values_in_attributes(attributes_list, continuous_attributes,
                                                       datazones_local_values_counts):
        global_values_counts = datazones_local_values_counts[0]
        for local_values_counts in datazones_local_values_counts[1:]:
            for i, local_attribute_values_counts_dict in enumerate(local_values_counts):
                if attributes_list[i] in continuous_attributes:
                    for key in local_attribute_values_counts_dict:
                        if global_values_counts[i].get(key):
                            global_values_counts[i][key] = (
                                global_values_counts[i].get(key)[0] + local_attribute_values_counts_dict.get(key)[0],
                                global_values_counts[i].get(key)[1] + local_attribute_values_counts_dict.get(key)[1])
                        else:
                            global_values_counts[i][key] = local_attribute_values_counts_dict.get(key)
                else:
                    for key in local_attribute_values_counts_dict:
                        if global_values_counts[i].get(key):
                            global_values_counts[i][key] = global_values_counts[i].get(key) + \
                                                           local_attribute_values_counts_dict.get(key)
                        else:
                            global_values_counts[i][key] = local_attribute_values_counts_dict.get(key)
        return global_values_counts

    @staticmethod
    def get_local_count_for_attribute_with_value(data, bins_array, attributes_list, attribute, value):
        # count the number of occurrences of a value of an attribute in the file
        attribute_index = -1

        for i, row_attribute in enumerate(attributes_list):
            if row_attribute == attribute:
                attribute_index = i
                break
        if attribute_index == -1:
            return 0  # Attribute Not found in File.
        if not bins_array[attribute_index]:
            count = 0
            for row in data:
                if row[attribute_index] == value:
                    count += 1
            return count
        else:
            count_smaller_or_equal = 0
            count_larger = 0
            for row in data:
                if float(row[attribute_index]) <= value:
                    count_smaller_or_equal += 1
                else:
                    count_larger += 1
            return count_smaller_or_equal, count_larger

    @staticmethod
    def get_local_count_for_all_class_values_in_values_in_attributes(data, bins_array, attributes_list, values):
        values_class_count = [{} for _ in attributes_list]
        for i, attribute in enumerate(attributes_list[:-1]):
            value_class_count_dict = {}
            for j, value in enumerate(values[i]):
                value_class_count_dict[value] = {}
                for h, class_value in enumerate(values[-1]):  # values[-1] is the class attribute
                    value_class_count_dict[value][class_value] = DecisionTreeExecutor.\
                        get_local_count_for_attribute_for_a_specific_value_of_class(data, attributes_list, bins_array,
                                                                                    attribute, value, class_value)
            values_class_count[i] = value_class_count_dict
        return values_class_count

    @staticmethod
    def get_global_count_for_all_class_values_in_values_in_attributes(attributes_list, continuous_attributes,
                                                                      datazones_local_values_class_counts):
        global_values_class_counts = datazones_local_values_class_counts[0]
        for local_values_class_counts in datazones_local_values_class_counts[1:]:
            for i, local_attribute_values_class_counts_dict in enumerate(local_values_class_counts):
                if attributes_list[i] in continuous_attributes:
                    for value_key in local_attribute_values_class_counts_dict:
                        if global_values_class_counts[i].get(value_key):
                            for class_key in local_attribute_values_class_counts_dict.get(value_key):
                                if global_values_class_counts[i].get(value_key).get(class_key):
                                    global_values_class_counts[i][value_key][class_key] = \
                                        (global_values_class_counts[i].get(value_key).get(class_key)[0] +
                                         local_attribute_values_class_counts_dict.get(value_key).get(class_key)[0],
                                         global_values_class_counts[i].get(value_key).get(class_key)[1] +
                                         local_attribute_values_class_counts_dict.get(value_key).get(class_key)[1])
                                else:
                                    global_values_class_counts[i][value_key][class_key] = \
                                        local_attribute_values_class_counts_dict.get(value_key).get(class_key)
                        else:
                            global_values_class_counts[i][value_key] = local_attribute_values_class_counts_dict.get(
                                value_key)
                else:
                    for value_key in local_attribute_values_class_counts_dict:
                        if global_values_class_counts[i].get(value_key):
                            for class_key in local_attribute_values_class_counts_dict.get(value_key):
                                if global_values_class_counts[i].get(value_key).get(class_key):
                                    global_values_class_counts[i][value_key][class_key] = \
                                        global_values_class_counts[i].get(value_key).get(class_key) + \
                                        local_attribute_values_class_counts_dict.get(value_key).get(class_key)
                                else:
                                    global_values_class_counts[i][value_key][class_key] = \
                                        local_attribute_values_class_counts_dict.get(value_key).get(class_key)
                        else:
                            global_values_class_counts[i][value_key] = local_attribute_values_class_counts_dict.get(
                                value_key)
        return global_values_class_counts

    @staticmethod
    def get_local_count_for_attribute_for_a_specific_value_of_class(data, attributes_list, bins_array, attribute,
                                                                    attribute_value, class_value):
            # count the number of occurrences of a specific class values having a value of an attribute in the file
            attribute_index = -1

            for i, row_attribute in enumerate(attributes_list):
                if row_attribute == attribute:
                    attribute_index = i
                    break
            if attribute_index == -1:
                return 0  # Attribute Not found in File.
            if not bins_array[attribute_index]:
                count = 0
                for row in data:
                    if row[attribute_index] == attribute_value and row[len(attributes_list) - 1] == class_value:
                        count += 1
                return count
            else:
                count_smaller_or_equal = 0
                count_larger = 0
                for row in data:
                    if row[len(attributes_list) - 1] == class_value:
                        if float(row[attribute_index]) <= attribute_value:
                            count_smaller_or_equal += 1
                        else:
                            count_larger += 1
                return count_smaller_or_equal, count_larger

    @staticmethod
    def calculate_value_gini(value_count, value_class_counts):  # calculate gini for value in attribute
        result = 1
        for value_class_count_key in value_class_counts:  # value_class_count is a dictionary
            result -= (value_class_counts.get(value_class_count_key) / value_count) ** 2
            # 1 - sigma (count class value / count value)^2
        return result

    @staticmethod
    def calculate_continuous_value_gini(value_counts, value_class_counts):  # calculate gini for value in attribute
        values_ginis = []
        for i, value_count in enumerate(value_counts):
            result = 1
            for value_class_count_key in value_class_counts:
                if value_count == 0:
                    continue   # TODO REMOVE DETECT IF ZERO DENOMINATOR
                result -= (value_class_counts.get(value_class_count_key)[i] / value_count) ** 2
                # 1 - sigma (count class value / count value)^2
            values_ginis.append(result)
        return values_ginis

    @staticmethod
    def calculate_attribute_gini(values, attribute_index, value_ginis, value_counts):
        # calculate gini index for attribute
        result = 0
        total_count = sum(value_counts.values())
        for i, _ in enumerate(value_ginis):  # value_counts is a dictionary
            result += (value_counts[values[attribute_index][i]] / total_count) * value_ginis[i]
            # Σ ((count value / count total values of attribute) * gini value)

        return result

    @staticmethod
    def calculate_continuous_attribute_gini(value_ginis, value_counts):  # calculate gini index for attribute
        result = 0
        total_count = sum(value_counts)
        for i, _ in enumerate(value_ginis):
            result += (value_counts[i] / total_count) * value_ginis[i]
            # sigma ((count value / count total values of attribute) * gini value)
        return result

    @staticmethod
    def get_sorted_list(main_list):  # returns the a numbered list containing the sorted gini index list
        sorted_list = [0 for _ in main_list]
        for i, item in enumerate(main_list):
            number_of_smaller_items = 0
            number_of_duplications = 0
            for j, inner_item in enumerate(main_list):
                if inner_item < item:
                    number_of_smaller_items += 1
                elif inner_item == item and i < j:
                    number_of_duplications += 1
            sorted_list[i] = number_of_smaller_items + number_of_duplications
        return sorted_list

    @staticmethod
    def get_the_partitioning_attribute(querying_values, attributes, continuous_attributes, values, values_counts,
                                       values_class_count):
        # decide the next partitioning attribute based on the min gini index of all attributes
        attributes_ginis = [0 for _ in attributes[:-1]]
        continuous_splitting_values = [_ for _ in attributes]
        continuous_values_class_counts = [[] for _ in attributes]

        # TODO EMPTY OR IMPURE LOGIC WAS REMOVED FROM HERE AND PUT IN THE EXECUTOR

        values_ginis = [list([]) for _ in attributes[:-1]]
        for i, attribute in enumerate(attributes[:-1]):
            if attribute not in continuous_attributes:
                value_ginis = [0 for _ in values[i]]
                for j, value in enumerate(values[i]):
                    value_ginis[j] = DecisionTreeExecutor.calculate_value_gini(values_counts[i][value],
                                                                               values_class_count[i][value])
                values_ginis[i] = value_ginis
                attributes_ginis[i] = DecisionTreeExecutor.calculate_attribute_gini(values, i, value_ginis,
                                                                                    values_counts[i])
            else:
                continuous_value_ginis = [[0, 0] for _ in values[i]]
                continuous_attribute_ginis = [0 for _ in values[i]]
                for j, value in enumerate(values[i]):
                    continuous_value_ginis[j] = DecisionTreeExecutor.calculate_continuous_value_gini(
                        values_counts[i][value], values_class_count[i][value])
                    continuous_attribute_ginis[j] = DecisionTreeExecutor.calculate_continuous_attribute_gini(
                        continuous_value_ginis[j], values_counts[i][value])
                min_bin_value_index = continuous_attribute_ginis.index(min(continuous_attribute_ginis))
                continuous_splitting_values[i] = values[i][min_bin_value_index]
                bins_sorted_list = DecisionTreeExecutor.get_sorted_list(continuous_attribute_ginis)
                nth_smallest_bin = 0
                querying_values_for_attribute = [querying_value for querying_attribute, querying_value in
                                                 querying_values if querying_attribute in continuous_attributes
                                                 and querying_attribute == attribute]
                for j, value in enumerate(querying_values_for_attribute):
                    if value[0] == "<":
                        querying_values_for_attribute[j] = value.split('=')[1]
                    else:
                        querying_values_for_attribute[j] = value.split('>')[1]
                all_bins_are_done = False
                while str(continuous_splitting_values[i]) in querying_values_for_attribute:
                    if nth_smallest_bin >= len(values[i]):
                        all_bins_are_done = True
                        attributes_ginis[i] = 1  # put max attribute index for not to be chosen
                        break
                    for j, number in enumerate(bins_sorted_list):
                        if number == nth_smallest_bin:
                            continuous_splitting_values[i] = values[i][j]
                            min_bin_value_index = j
                            nth_smallest_bin += 1
                            break
                if not all_bins_are_done:
                    attributes_ginis[i] = continuous_attribute_ginis[min_bin_value_index]
                    values_ginis[i] = continuous_value_ginis[min_bin_value_index]
                    continuous_values_class_counts[i] = values_class_count[i][values[i][min_bin_value_index]].values()
                    # set best value gini to be the values_ginis

        if all(item == 1 for item in attributes_ginis):
            return "Impure", "Impure", "Impure", values[-1], "Impure", "Impure", "Impure"
            # TODO HANDLE THESE SEVEN Impurities

        min_attribute_index = attributes_ginis.index(min(attributes_ginis))
        min_attribute = attributes[min_attribute_index]

        pure_attribute_class_value = []
        pure_attribute_class_count = []

        nth_smallest = 0
        sorted_list = DecisionTreeExecutor.get_sorted_list(attributes_ginis)
        impure_class_count = []
        while min_attribute in [querying_attribute for querying_attribute, _ in querying_values] and min_attribute \
                not in continuous_attributes:  # loop to search the best non duplicate attribute to partition
            if nth_smallest > len(attributes_ginis) - 1:  # impure branch
                _, value_dict = values_class_count[0].popitem()
                impure_class_count = list(value_dict.values())
                # TODO double CHECK values[0][0] is it correct in case of continuous
                break
            for i, number in enumerate(sorted_list):
                if number == nth_smallest:
                    min_attribute = attributes[i]
                    min_attribute_index = i
                    nth_smallest += 1
                    break

        if min_attribute in continuous_attributes:  # TODO NEEDS CODE REFACTORING
            smaller_list = []
            larger_list = []
            for continuous_value_class_count in continuous_values_class_counts[min_attribute_index]:
                smaller, larger = continuous_value_class_count
                smaller_list.append(smaller)
                larger_list.append(larger)
            # value_class_counts means (<s,>s),(<c,>c)
            for i, value_gini in enumerate(values_ginis[min_attribute_index]):
                if value_gini == 0:
                    if i == 0:
                        for j, smaller_item in enumerate(smaller_list):
                            if smaller_item != 0:
                                pure_attribute_class_value.append(values[-1][j])
                                pure_attribute_class_count.append(smaller_item)
                    else:
                        for j, larger_item in enumerate(larger_list):
                            if larger_item != 0:
                                pure_attribute_class_value.append(values[-1][j])
                                pure_attribute_class_count.append(larger_item)
        else:
            for i, value_gini in enumerate(values_ginis[min_attribute_index]):
                if value_gini == 0:
                    for j, count_class_value in enumerate(values_class_count[min_attribute_index]
                                                          [values[min_attribute_index][i]]):
                        if values_class_count[min_attribute_index][values[min_attribute_index][i]][count_class_value] \
                                != 0:
                            pure_attribute_class_value.append(count_class_value)
                            pure_attribute_class_count.append(values_class_count[min_attribute_index]
                                                              [values[min_attribute_index][i]][count_class_value])

        if min_attribute in continuous_attributes:
            continuous_values = ['<={}'.format(continuous_splitting_values[min_attribute_index]), '>{}'.format(
                continuous_splitting_values[min_attribute_index])]
            return min_attribute, continuous_values, values_ginis[min_attribute_index], values[-1], \
                pure_attribute_class_value, pure_attribute_class_count, impure_class_count
        else:
            return min_attribute, values[min_attribute_index], values_ginis[min_attribute_index], values[-1], \
                   pure_attribute_class_value, pure_attribute_class_count, impure_class_count

    @staticmethod
    def get_node_from_tree(tree, querying_values):
        updating_node = tree.root
        for tuple_attribute, tuple_value in querying_values[:-1]:  # loop to get the branch node
            if updating_node.data == tuple_attribute:
                updating_index = updating_node.edge_values.index(tuple_value)
                updating_node = updating_node.children[updating_index]
        return updating_node

    @staticmethod
    def update_decision_tree(tree, branch, max_depth, attribute, values, value_ginis, class_values,
                             pure_attribute_class_values, pure_attribute_class_count, impure_class_count,
                             continuous_attributes, attributes_list, class_value_count):
        # populate the tree based on the data zone and all the connected datazones
        resulting_branches = []
        if attribute == "Impure":
            updating_node = DecisionTreeExecutor.get_node_from_tree(tree, branch)
            node = Node(attributes_list[-1], class_values)
            updating_node.add_child_node(node, updating_node.edge_values.index(branch[-1][1]))
            updating_node = updating_node.children[updating_node.edge_values.index(branch[-1][1])]
            for i, class_value in enumerate(class_values):
                impure_node = Node("Impure", [class_values[i]])
                impure_node.class_value = class_value
                impure_node.occurrence_count = class_value_count[class_values[i]]
                updating_node.children[i] = impure_node
            return tree, None

        if attribute == "Empty":
            empty_node = Node("Empty", [])
            updating_node = DecisionTreeExecutor.get_node_from_tree(tree, branch)
            _, tuple_value = branch[-1]
            updating_index = updating_node.edge_values.index(tuple_value)
            updating_node.add_child_node(empty_node, updating_index)
            return tree, None

        pure_attribute_index = 0
        if not branch:  # starting case where no tree and branch
            tree = DecisionTree(attribute, values)
            tree.root.all_count = sum(list(class_value_count.values()))

            for i, value_gini in enumerate(value_ginis):
                if value_ginis[i] == 0:
                    pure_node = Node("Pure", [values[i]])
                    pure_node.class_value = pure_attribute_class_values[pure_attribute_index]
                    pure_node.occurrence_count = pure_attribute_class_count[pure_attribute_index]
                    pure_attribute_index += 1
                    tree.root.add_child_node(pure_node, i)
                    continue
                resulting_branches.append(branch + [(attribute, values[i])])
            return tree, resulting_branches
        else:  # normal branching case
            for att, val in branch:
                if att == attribute and attribute not in continuous_attributes:
                    # condition for impurities
                    updating_node = DecisionTreeExecutor.get_node_from_tree(tree, branch)

                    node = Node(attributes_list[-1], class_values)
                    node.all_count = sum(list(class_value_count.values()))
                    updating_node.add_child_node(node, updating_node.edge_values.index(branch[-1][1]))
                    updating_node = updating_node.children[updating_node.edge_values.index(branch[-1][1])]
                    for i, class_value in enumerate(class_values):
                        impure_node = Node("Impure", [class_values[i]])
                        impure_node.class_value = class_value
                        impure_node.occurrence_count = impure_class_count[i]
                        updating_node.children[i] = impure_node
                    return tree, None

            updating_node = DecisionTreeExecutor.get_node_from_tree(tree, branch)
            _, tuple_value = branch[-1]
            updating_index = updating_node.edge_values.index(tuple_value)

            if len(branch) <= max_depth:
                node = Node(attribute, values)
                node.all_count = sum(list(class_value_count.values()))
                updating_node.add_child_node(node, updating_index)
            else:
                depth_exceeded_node = Node("Max_Depth", class_values)
                for j in range(len(depth_exceeded_node.children)):
                    impure_node = Node("Impure", [class_values[j]])
                    impure_node.class_value = class_values[j]
                    impure_node.occurrence_count = class_value_count[class_values[j]]
                    depth_exceeded_node.children[j] = impure_node
                updating_node.add_child_node(depth_exceeded_node, updating_index)
                return tree, None

            child_index = None
            for i, edge_value in enumerate(updating_node.edge_values):
                _, branch_value = branch[-1]
                if edge_value == branch_value:
                    child_index = i

            for i, value_gini in enumerate(value_ginis):  # loop to add pure nodes
                if value_gini == 0:
                    pure_node = Node("Pure", [values[i]])
                    pure_node.class_value = pure_attribute_class_values[pure_attribute_index]
                    pure_node.occurrence_count = pure_attribute_class_count[pure_attribute_index]
                    pure_attribute_index += 1
                    updating_node.children[child_index].add_child_node(pure_node, i)
                    continue
                resulting_branches.append(branch + [(attribute, values[i])])
            return tree, resulting_branches

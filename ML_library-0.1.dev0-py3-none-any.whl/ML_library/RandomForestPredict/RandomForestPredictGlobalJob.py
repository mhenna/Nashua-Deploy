import shutil
from ML_library.Job import Job


class RandomForestPredictGlobalJob(Job):
    prev_paths = ""
    output_path = ""

    def __init__(self, output_path, prev_paths):
        super().__init__(output_path)
        self.prev_paths = prev_paths.split(',')

    def execute(self):
        self.global_job_init()

    def global_job_init(self):
        for file_path in self.prev_paths:
            shutil.copyfile(file_path, self.output_path + '/' + file_path.split('/')[-1])

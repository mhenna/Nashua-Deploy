import pickle
import csv
import json
from ML_library.Job import Job
from sklearn.metrics import confusion_matrix, average_precision_score, precision_score, recall_score, f1_score,\
    accuracy_score, matthews_corrcoef, roc_auc_score


class RandomForestPredictLocalJob(Job):
    test_path = ""
    model_path = ""
    output_path = ""
    forest = None
    test_features = []
    test_labels = []
    labels_included = False
    show_results = False

    def __init__(self, output_path, test_path, model_path, labels_included=False, show_results=False):
        super().__init__(output_path)
        self.test_path = test_path
        self.model_path = model_path
        self.labels_included = labels_included
        self.show_results = show_results

    def execute(self):
        self.local_job_init()

    def local_job_init(self):
        self.read_data_from_csv()
        self.unpickle_model()

        predictions = self.forest.predict(self.test_features)
        predictions_proba = self.forest.predict_proba(self.test_features)

        predictions = [float(prediction) for prediction in predictions]

        self.test_labels = [float(label) for label in self.test_labels]

        if self.labels_included:
            tn, fp, fn, tp = confusion_matrix(self.test_labels, predictions).ravel()

            mcc = matthews_corrcoef(self.test_labels, predictions)
            precision = precision_score(self.test_labels, predictions)
            recall = recall_score(self.test_labels, predictions)
            f1score = f1_score(self.test_labels, predictions)
            accuracy = accuracy_score(self.test_labels, predictions)
            auc = roc_auc_score(self.test_labels, predictions_proba[:, 1])
            test_ap = average_precision_score(self.test_labels, predictions_proba[:, 1])

            if self.show_results:
                results = ''
                resultsJSON = {}
                results += "---------- RESULTS ---------------\n"
                results += "TP: {}\n".format(tp)
                resultsJSON['TP'] = int(tp)
                results += "TN: {}\n".format(tn)
                resultsJSON['TN'] = int(tn)
                results += "FP: {}\n".format(fp)
                resultsJSON['FP'] = int(fp)
                results += "FN: {}\n".format(fn)
                resultsJSON['FN'] = int(fn)
                results += "----------------------------------\n"
                results += "Precision: {}\n".format(precision)
                resultsJSON['Precision'] = float(precision)
                results += "Recall: {}\n".format(recall)
                resultsJSON['Recall'] = float(recall)
                results += "Accuracy: {}\n".format(accuracy)
                resultsJSON['Accuracy'] = float(accuracy)
                results += "F SCORE: {}\n".format(f1score)
                resultsJSON['F SCORE'] = float(f1score)
                results += "MCC: {}\n".format(mcc)
                resultsJSON['MCC'] = float(mcc)
                results += "Average Precision: {}\n".format(test_ap)
                resultsJSON['Average Precision'] = float(test_ap)
                results += "AUC: {}\n".format(auc)
                resultsJSON['AUC'] = float(auc)
                results += "----------------------------------\n"

                print(results)

                self.save_object_into_file(results, 'results', 'txt')
                self.save_object_into_file(resultsJSON, 'resultsJson', 'json')
                

        self.save_object_into_file(predictions, 'predictions', 'csv')
        self.save_object_into_file(predictions_proba, 'predictions_proba', 'csv')

    def read_data_from_csv(self):
        test_features = []
        test_labels = []
        with open(self.test_path, newline='') as csv_file:
            reader = csv.reader(csv_file)
            if self.labels_included:
                for row in reader:
                    test_features.append(row[:-1])
                    test_labels.append(row[-1])
            else:
                for row in reader:
                    test_features.append(row)
        self.test_features = test_features
        self.test_labels = test_labels

    def unpickle_model(self):
        with open(self.model_path, 'rb') as pkl_input:
            self.forest = pickle.load(pkl_input)

    def save_object_into_file(self, the_object, file_name, extension):
        if extension == 'pkl':
            with open('{}/{}'.format(self.output_path, file_name + '.pkl'), 'wb') as output_file:
                pickle.dump(the_object, output_file, pickle.HIGHEST_PROTOCOL)
        elif extension == 'csv':
            with open('{}/{}'.format(self.output_path, file_name + '.csv'), 'w', newline='') as output_file:
                writer = csv.writer(output_file, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)
                for row in enumerate(the_object):
                    writer.writerow(row)
        elif extension == 'txt':
            with open('{}/{}'.format(self.output_path, file_name + '.txt'), 'w', newline='') as output_file:
                output_file.write(the_object)
        elif extension == 'json':
            with open('{}/{}'.format(self.output_path, file_name + '.json'), 'w', newline='') as output_file:
                json.dump(the_object, output_file)
        else:
            raise EnvironmentError("Unsupported format: Please choose either pkl, txt or csv")

import os
import argparse
from ML_library.RandomForestPredict.RandomForestPredictLocalJob import RandomForestPredictLocalJob
from ML_library.RandomForestPredict.RandomForestPredictGlobalJob import RandomForestPredictGlobalJob
from ML_library.Job import Job


class RandomForestPredictHandler(Job):
    class_object = None
    parser = None

    def __init__(self, args):
        self.create_parser()

        args, extra_args = self.parser.parse_known_args(args)

        input_path = args.inputPath
        prev_paths = args.previousResults
        output_path = args.outputPath
        labels_included = args.labelsIncluded
        show_results = args.showResults
        model_path = args.additionalFilesReferences
        is_global = args.isGlobal

        super(RandomForestPredictHandler, self).__init__(output_path)

        if not os.path.exists(output_path):
            os.makedirs(output_path)

        if is_global == 'false':
            self.class_object = RandomForestPredictLocalJob(output_path, input_path, model_path,
                                                            labels_included=labels_included, show_results=show_results)
        else:
            self.class_object = RandomForestPredictGlobalJob(output_path, prev_paths)

    def execute(self):
        self.class_object.execute()

    def create_parser(self):
        self.parser = argparse.ArgumentParser()
        self.parser.add_argument("--inputPath")
        self.parser.add_argument("--testPath")
        self.parser.add_argument("--previousResults")
        self.parser.add_argument("--outputPath")
        self.parser.add_argument("--isGlobal")
        self.parser.add_argument("--labelsIncluded", default=False, const=True, nargs='?', type=bool)
        self.parser.add_argument("--showResults", default=False, const=True, nargs='?', type=bool)
        self.parser.add_argument("--additionalFilesReferences")

import argparse
import importlib

parser = argparse.ArgumentParser()
parser.add_argument("--jobName")

args = parser.parse_known_args()
print("args in  main: ", args)
class_name = args[0].jobName
algorithm_library = importlib.import_module('ML_library.{}'.format(class_name))
class_object = getattr(algorithm_library, class_name + "Handler")(args[1])
class_object.execute()

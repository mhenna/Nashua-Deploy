from ML_library.Job import Job
import pandas as pd
import pickle
import os
import csv
from tsfresh.feature_extraction import extract_features, EfficientFCParameters
import time
import logging
import argparse


class BleedAirSystemProcessingHandler(Job):
    class_object = None

    def __init__(self, args):
        self.parser = argparse.ArgumentParser()
        self.create_parser()
        args, extra_args = self.parser.parse_known_args(args)

        input_path = args.inputPath
        output_path = args.outputPath

        super(BleedAirSystemProcessingHandler, self).__init__(output_path)

        if not os.path.exists(output_path):
            os.makedirs(output_path)

        if not os.path.exists(output_path + "/concat_train_features.csv"):
            os.mknod(output_path + "/concat_train_features.csv")

        total_start = time.time()

        len_files = len(os.listdir(input_path + "/Train_files"))

        if not os.path.exists(output_path + '/pickles_train/'):
            os.makedirs(output_path + '/pickles_train/')

        for i in range(len_files):
            file_name = 'flight{}.csv'.format(i + 1)
            start = time.time()
            logging.info("starting file {} at {} s".format(file_name, start))
            df = pd.read_csv(input_path + "/Train_files" + '/' + file_name, sep=';')
            logging.info("finished reading file {}".format(file_name))
            df = df.loc[df['FLIGHT_PHASE'].isin(['6', '7', '8', '9'])]
            df['ID'] = [i for _ in range(df.count()[0])]
            df = df[['ID', 'COL_1', 'COL_2', 'COL_3', 'COL_4']]
            try:
                features = extract_features(df, column_id='ID', default_fc_parameters=EfficientFCParameters(),
                                            n_jobs=4, show_warnings=True)
            except Exception as e:
                print(e)
                print(e.__cause__)
                raise e

            logging.info("Writing features to concat_train_features file...")
            with open(output_path + "/concat_train_features.csv", 'a') as fd:
                writer = csv.writer(fd)
                writer.writerow(features)
            logging.info("Finished writing features to concat_train_features file")
            with open(output_path + '/pickles_train/{}.pkl'.format(file_name.replace('.csv', '')), 'wb') as output:
                pickle.dump(features, output, pickle.HIGHEST_PROTOCOL)
            end = time.time()
            logging.info("Finished file {} at {}".format(file_name, end - start))
            print("Time: ", end - start)

        filtered_cols = [ 'COL_1__maximum', 'COL_3__abs_energy', 'COL_4__maximum', 'COL_4__quantile__q_0.9']

        filtered_concat_features = pd.read_csv(output_path + "/concat_train_features.csv", usecols=filtered_cols)

        filtered_concat_features.to_csv(output_path + "/filtered_concat_features.csv")

        print("ended")
        total_end = time.time()
        print("Time: ", total_end - total_start)

    def execute(self):
        print("init finished and done executing")

    def create_parser(self):
        self.parser.add_argument("--inputPath")
        self.parser.add_argument("--outputPath")

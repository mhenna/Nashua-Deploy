class Job(object):
    output_path = ''

    def __init__(self, output_path):
        self.output_path = output_path

    def execute(self):
        raise NotImplementedError("You can't call execute function of Abstract job, inhereted class must implement"
                                  " its own execute function")
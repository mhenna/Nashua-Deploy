import pip
import argparse
import pathlib

failed = []

parser = argparse.ArgumentParser()
parser.add_argument("--jobName")

args = parser.parse_known_args()

print("args in  init: ", args)

algorithm_dir = args[0].jobName
requirements_file_name = algorithm_dir + "Requirements.txt"
requirements_path = pathlib.Path(__file__).parent / algorithm_dir /requirements_file_name
print("FILE --> ", requirements_path)
requirements = open(requirements_path, "r")
print("Installing req. from ML library")
for req in requirements:
    if pip.main(["install", req]) == 1:
        failed.append(req)

if not failed:
    print("Req. installed successfully from ML library")
else:
    print("Error requirements failed: ", failed)
    raise ImportError("Error while installing this list of requirements: {}". format(failed))
